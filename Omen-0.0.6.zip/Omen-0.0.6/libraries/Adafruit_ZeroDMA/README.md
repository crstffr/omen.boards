# Adafruit_ZeroDMA library [![Build Status](https://github.com/adafruit/Adafruit_ZeroDMA/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_ZeroDMA/actions)

DMA helper/wrapped for ATSAMD21 such as Arduino Zero &amp; Feather M0

Current version of this library no longer requires Adafruit_ASFcore as a prerequisite. However...IT BREAKS COMPATIBILITY WITH PRIOR VERSIONS. Function names, calling sequence and return types/values have changed. See examples!

Item(s) in 'utility' directory are much pared-down derivatives of Atmel ASFcore 3 files. Please keep their original copyright and license intact when editing.
